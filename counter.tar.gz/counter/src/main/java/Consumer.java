public class Consumer {

    public  static void main(String args[]){

        KafkaStream.runConsumer();


    }
}

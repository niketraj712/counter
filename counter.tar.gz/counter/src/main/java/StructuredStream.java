

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.internal.SQLConf;
import org.apache.spark.sql.streaming.OutputMode;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;


public class StructuredStream
{
   public  void structured() throws Exception{
        System.setProperty("hadoop.home.dir", "c:/hadoop");
        Logger.getLogger("org.apache").setLevel(Level.WARN);
        Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR);

        SparkSession session = SparkSession.builder()
                .master("local[*]")
                .appName("structuredViewingReport")
                .getOrCreate();

        session.conf().set("spark.sql.shuffle.partitions", "10");

        Dataset<Row> results = session.readStream()
                .format("kafka")
                .option("kafka.bootstrap.servers", "localhost:9092")
                .option("subscribe", "demo")
                .load();


        // start some dataframe operations
         results.createOrReplaceTempView("tableview");

        // key, value, timestamp
       Dataset<Row> results1 =
                session.sql("select cast(key as string),cast(value as string) from tableview");

        Dataset<Row> resultsnew=results1.groupBy(
                functions.window(results1.col("value"), "5 seconds", "2 seconds"),
                results1.col("key")
        ).count();


        StreamingQuery query = resultsnew
                .writeStream()
                .format("console")
                .outputMode(OutputMode.Update())
                .option("truncate", false)
                .option("numRows", 50)
                .start();


        query.awaitTermination();

    }
}

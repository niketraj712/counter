import java.sql.*;
import java.util.HashMap;
import java.util.Map;


public class Jdbc {


    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/emp";


    static final String USER = "root";
    static final String PASS = "niket712";
    Connection conn = null;
    Statement stmt = null;


    void insert() {
        try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Inserting records into the table...");
            PreparedStatement stmt=conn.prepareStatement("insert into example values(?,?)");



            Map<String,Integer> fin=Counter.getc();
            for (Map.Entry<String,Integer> entry : fin.entrySet()){
                stmt.setString(1,entry.getKey());
                stmt.setInt(2,entry.getValue());
                int i=stmt.executeUpdate();
                System.out.println(i +" records inserted...");}


        } catch (
                SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null)
                    conn.close();
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        System.out.println("Goodbye!");
    }
}



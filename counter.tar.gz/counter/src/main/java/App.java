
import io.undertow.Handlers;
import io.undertow.Undertow;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import org.apache.kafka.clients.producer.Producer;

import java.sql.Timestamp;


public class App 
{

	public static void main(final String[] args) {


	final Counter counter = new Counter();
	final Jdbc jdbc = new Jdbc();
		final Jdbc2 jdbc2 = new Jdbc2();
		SparkDStream sparkStream=new SparkDStream();
		StructuredStream structuredStream=new StructuredStream();


		Undertow server = Undertow.builder()
		.addHttpListener(8080, "localhost")
		.setHandler(Handlers.routing()
				/*.get("{path}",new CountHandler(){

					public void handleRequest(HttpServerExchange exchange) throws Exception {

						String path = exchange.getQueryParameters().get("path").toString();

						exchange.getResponseSender().send(path);

							counter.updateCounter(path);
							//long count=Counter.mp.get(path);

					}


				})*/
                       .get("{path}",new CountHandler(){

                            public void handleRequest(HttpServerExchange exchange) throws Exception {

                                String path = exchange.getQueryParameters().get("path").toString();

                               exchange.getResponseSender().send(path);
                                Timestamp timestamp = new Timestamp(System.currentTimeMillis());



                               	//counter.updateList(path,timestamp);
								//SampleProducer producerThread = new SampleProducer("demo", false);
								//producerThread.run(path,timestamp.toString());


								KafkaStream.runProducer(path,timestamp.toString());
//                               / KafkaStream.runConsumer();


                            }

                        })

				/*.get("{path}",new CountHandler(){

					public void handleRequest(HttpServerExchange exchange) throws Exception {

						String path = exchange.getQueryParameters().get("path").toString();

						exchange.getResponseSender().send(path);
						Timestamp timestamp = new Timestamp(System.currentTimeMillis());

						counter.updateList(path,timestamp);
					}

				})*/

					/*	.get("timeinsert", new HttpHandler() {
							public void handleRequest(HttpServerExchange exchange) throws Exception {

								jdbc2.insert();
								exchange.getResponseSender().send("insertion done");
							}
						})*/

						.get("api/getCount", new HttpHandler() {
					public void handleRequest(HttpServerExchange exchange) throws Exception {

						exchange.getResponseSender().send(counter.getCount());



					}
				})
						.get("sparkstream", new HttpHandler() {
							public void handleRequest(HttpServerExchange exchange) throws Exception {


							sparkStream.SparkStream();


							}
						})		.get("structured", new HttpHandler() {
							public void handleRequest(HttpServerExchange exchange) throws Exception {

								structuredStream.structured();
								exchange.getResponseSender().send("Structure streaming started");

							}})


						.get("batchtime", new HttpHandler() {
            public void handleRequest(HttpServerExchange exchange) throws Exception {

                jdbc2.batchinsertbytime();
                exchange.getResponseSender().send("batch insertion done");

            }}).get("batchrecords", new HttpHandler() {
                            public void handleRequest(HttpServerExchange exchange) throws Exception {

                                jdbc2.batchinsertbyrecords();
                                exchange.getResponseSender().send("batch insertion done");

                            }})

		.get("insert", new HttpHandler() {
			public void handleRequest(HttpServerExchange exchange) throws Exception {

				jdbc.insert();
				exchange.getResponseSender().send("insertion done");
			}
		})
		)

		.build();
		server.start();


	}}






import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class Nsp {

    public static void main(String[] args) throws Exception {


        SparkSession spark = SparkSession.builder()
                .master("local")
                .appName("Spark CSV Reader")
                .getOrCreate();

       Dataset<Row> df= spark.read().format("csv").csv("/home/niket/Desktop/ids.csv").toDF();
        System.out.println(df.count());

    }
}

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class Counter {



    public Counter(){


    }


   static   public Map<String, Integer> mp=new HashMap<String,Integer>();
   static ArrayList<String> arr1=new ArrayList<String>();
    static ArrayList<Timestamp> arr2=new ArrayList<Timestamp>();

    synchronized void  updateCounter(String path){

    if(mp.containsKey(path)){

        mp.put(path,mp.get(path)+1);

    }else{
        mp.put(path,1);
    }


    }
    String getCount(){
        StringBuffer buf = new StringBuffer();
        for (Map.Entry<String,Integer> entry : mp.entrySet()){
            buf.append(entry.getKey()+"\t:"+entry.getValue()+"\n");
    }
        return buf.toString();
    }

 static Map getc(){

        Map<String,Integer> map= mp;
        return map;


}
    void updateList(String  path, Timestamp sys){

        arr1.add(path);
        arr2.add(sys);
    }

    static ArrayList<String> getlink(){

        ArrayList<String> narr1=arr1;
        return narr1;

    }
    static ArrayList<Timestamp> getime(){

        ArrayList<Timestamp> narr2=arr2;
        return narr2;

    }

}

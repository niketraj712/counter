import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.serialization.Deserializer;

import java.sql.Timestamp;
import java.util.Map;

public class CustomDeserializer implements Deserializer {


    @Override
    public void configure(Map map, boolean b) {

    }

    @Override
    public Timestamp deserialize(String topic, byte[] data) {
        ObjectMapper mapper = new ObjectMapper();
        Timestamp object = null;
        try {
            object = mapper.readValue(data, Timestamp.class);
        } catch (Exception exception) {
            System.out.println("Error in deserializing bytes " + exception);
        }
        return object;
    }

    @Override
    public void close() {
    }
}
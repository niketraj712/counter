

import java.sql.*;
import java.util.*;
import java.util.Date;


public class Jdbc2 {

    Timer timer = new Timer();
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/emp";


    static final String USER = "root";
    static final String PASS = "niket712";
    Connection conn = null;
    Statement stmt = null;


    void batchinsertbyrecords() {
        try {
            int j=0;
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Inserting records into the table...");
            PreparedStatement stmt = conn.prepareStatement("insert into time values(?,?)");


            ArrayList<String> farray1 = Counter.getlink();
            ArrayList<Timestamp> farray2 = Counter.getime();
            int len = farray1.size();
            for (int i = 0; i < len; i++) {
                String newlink = farray1.get(i);
                Timestamp newtime = farray2.get(i);
                stmt.setString(1, newlink);
                stmt.setTimestamp(2, newtime);
                stmt.addBatch();
                i++;
                if (i==100 || i==len){
                stmt.executeBatch();
                System.out.println(j + " records inserted...");
                j++;
            }}


        } catch (
                SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null)
                    conn.close();
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        System.out.println("Goodbye!");
    }

    public void batchinsertbytime() throws SQLException {
        try {
           int interval=1000;

          //  System.out.println("Connected database successfully...");
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            // System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            final PreparedStatement statement = conn.prepareStatement("insert into time1 values(?,?)");
            ArrayList<String> farray1 = Counter.getlink();
            ArrayList<Timestamp> farray2 = Counter.getime();
            Date timeToRun = new Date(System.currentTimeMillis());
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    try {
                        statement.executeBatch();
                        System.out.println("batch inserted");
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            },timeToRun,2000);
            int len = farray1.size();
            int i ;
            for (i = 0 ;i < len-1;) {
                String newlink = farray1.get(i);
                Timestamp newtime = farray2.get(i);
                statement.setString(1, newlink);
                statement.setTimestamp(2, newtime);

                statement.addBatch();
                i++;


            }
            timer.cancel();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        }

    }
}
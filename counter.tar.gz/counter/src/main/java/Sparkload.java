import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;

public class Sparkload {




        public static String SPACE_DELIMITER = " ";
        public static void main(String[] args) throws Exception {

            SparkConf conf = new SparkConf().setMaster("local[*]").setAppName("SparkFileSumApp");
            JavaSparkContext sc = new JavaSparkContext(conf);

            JavaRDD<String> input = sc.textFile("/home/niket/Desktop/AvgNumbers.txt");
            System.out.println(input.getNumPartitions());
           JavaRDD<String> numberStrings = input.flatMap(s -> Arrays.asList(s.split(SPACE_DELIMITER)).iterator());


           // JavaRDD<String> validNumberString = numberStrings.filter(string -> !string.isEmpty());
           //JavaRDD<String> numbers = validNumberString.map(numberString -> String.valueOf(numberString));
          //long finalSum = numbers.reduce((x,y) -> x+y);
            //System.out.println( numbers.countByValue());


          // System.out.println("Final sum is: " + finalSum);
           // System.out.println("total count is "+numbers.count());
           // System.out.println("loaded");
            sc.close();
        }
    }



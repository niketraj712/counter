import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
/**
 * Producer Example in Apache Kafka
 * @author www.tutorialkart.com
 */
public class SampleProducer extends Thread {
    private final KafkaProducer producer;
    private final String topic;
    private final Boolean isAsync;
    public static final String KAFKA_SERVER_URL = "localhost";
    public static final int KAFKA_SERVER_PORT = 9092;
    public static final String CLIENT_ID = "client1";


    public SampleProducer(String topic, Boolean isAsync) {
        Properties properties = new Properties();
        properties.put("bootstrap.servers", KAFKA_SERVER_URL + ":" + KAFKA_SERVER_PORT);
        properties.put("client.id", CLIENT_ID);
        properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        producer = new KafkaProducer(properties);
        this.topic = topic;
        this.isAsync = isAsync;
    }

    public void fetch(String path,String time){
        String newpath,newtime;
        newtime=time;



    }

    public void run(String path,String time) {


                while(true){
            //   if (isAsync) { // Send asynchronously
                //   producer.send(new ProducerRecord&lt;&gt;(topic,
                //  messageNo,
                //   messageStr), new DemoCallBack(startTime, messageNo, messageStr));
                // Send synchronously
                try {
                    producer.send(new ProducerRecord(topic,
                            path,
                            time)).get();

                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                    // handle the exception
                }
            }

        }
    }
